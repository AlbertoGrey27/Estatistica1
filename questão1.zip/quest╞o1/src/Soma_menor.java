public class Soma_menor {

    public void menorSoma(Fila fila1, Fila fila2){
        
        
        if(fila1.somar() <= fila2.somar()){
            System.out.println("Fila 1 é menor");
        }else{
            System.out.println("Fila 2 é menor");
        }
    }
    
}
