public class Fila {
    Node head,tail;

    public Fila() {
    }

    public void adicionar(int data){
        Node newnode = new Node(data);
        if (head==null) {
            head = newnode;
            tail = newnode;
        }else{
            Node temp = tail;
            tail.next = newnode;
            newnode.prev = temp;
            tail = newnode;
        }
    }

    public int somar(){
        int cont=0;
        Node temp = tail;
        while (temp!=null) {
            
            cont = cont + temp.data;
            System.out.println(cont+" + "+temp.data+" = "+cont);
            temp = temp.prev;
            
        }
        return cont;
    }
    
}
