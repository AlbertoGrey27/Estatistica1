public class App {
    public static void main(String[] args) throws Exception {
        /*1 - Desenvolva um algoritmo em Java chamado fila_menor_soma que recebe duas filas de inteiros como parâmetros e retorna a fila cuja soma dos elementos é menor.
        Se as duas filas tiverem soma igual, a função deve retornar a primeira fila.
        Obs: A fila deve ser baseada em nós. */
        Fila fila1 = new Fila();
        fila1.adicionar(0);
        fila1.adicionar(1);
        fila1.adicionar(2);
        Fila fila2 = new Fila();
        fila2.adicionar(0);
        fila2.adicionar(2);
        fila2.adicionar(3);
        Soma_menor menor = new Soma_menor();
        menor.menorSoma(fila1, fila2);
        
    }
}
