public class App {
    public static void main(String[] args) throws Exception {
        Fila fila = new Fila();

        fila.add(1);
        fila.peek();
        fila.peekTail();
        fila.add(2);
        fila.peek();
        fila.peekTail();
        fila.remove();
        fila.add(3);
        fila.peek();
        fila.peekTail();
        System.out.println(fila.tail.date);
        System.out.println(fila.tail.prev.date);
        System.out.println(fila.head.date);
        System.out.println(fila.head.next.date);


       
    }
}
