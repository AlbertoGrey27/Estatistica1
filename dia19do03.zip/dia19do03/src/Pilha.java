public class Pilha {
    Node head;
    int tamanho, cont=0;
    

    public Pilha(int tamanho) {
        this.head = null;
       this.tamanho = tamanho;
    }

    public void push(int date){
        Node newnode = new Node(date);

        if (cont>=tamanho) {
            System.out.println("pilha cheia");
        }else{
            if (head == null) {
                head = newnode;
                cont=1;
            }else{
                Node temp = head;
    
                head = newnode;
                head.next = temp;
                cont++;
            }
        }
    }

    public void pop(){
        
        if(head==null){
            System.out.println("Não tem nada na pilha");
            cont=0;
        }else{
            head = head.next;
            cont--;
        }
    }

    public void peek(){
        System.out.println(head.date);
        
    }

    public void isEmpty(){
        if(cont==0){
            System.out.println("Não tem nada na pilha");
        }
    }

    public void isFull(){
        if(cont<=tamanho){
            System.out.println("A pilha esta cheia");
        }
    }

}
