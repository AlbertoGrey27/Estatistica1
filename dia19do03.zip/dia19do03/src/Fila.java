public class Fila {
    Node head,tail;
    int cont=0;

    public Fila() {
        this.head = null;
        this.tail = null;
    }

    public void add(int data){
        Node newnode = new Node(data);
        if (tail == null) {
            head = newnode;
            tail = newnode;
            cont=1;
        }else{
            
            tail.next = newnode;
            newnode.prev = tail;
            tail = newnode;

            cont++;
            /*int tempCont=cont;
            while(tail!=null && tempCont!=0){
                current = current.prev;
                head.next = current;
            }*/
        }
    }

    public void remove(){
        head = head.next;
        head.prev = null;
        cont--;
    }

    public void peek(){
        System.out.println(head.date); 
        
        System.out.println();
    }

    public void peekTail(){
        System.out.println(tail.date); 
     
        System.out.println();
    }

    public void isEmpty(){
        if(cont==0){
            System.out.println("Não tem nada na pilha");
        }
    }

    public void size(){
        System.out.println("Tamanho da fila é "+cont);
    }
    
        
}
