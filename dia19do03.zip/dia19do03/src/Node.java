public class Node {
    int date;
    Node next, prev;

    public Node(int date){
        this.date = date;
        this.next = null;
        this.next = null;

    }
    
}
