public class Node {
    Node next;
    int data;
    public Node(int data) {
        
        this.next = null;
        this.data = data;
    }
    
}
