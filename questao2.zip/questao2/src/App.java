public class App {
    public static void main(String[] args) throws Exception {
        /*2 - Implemente o algoritmo guindaste_mais_esforcado, que recebe como parâmetros duas pilhas de inteiros representando
        os pesos das cargas movimentadas por cada guindaste. A função deve retornar a pilha do guindaste que realizou o maior esforço total,
        definido como o produto dos pesos movimentados.
        Se ambos os guindastes tiverem o mesmo esforço total, retorne a pilha do segundo guindaste. */

        Pilha pilha1 = new Pilha();
        Pilha pilha2 = new Pilha();
        pilha1.adicionar(1);
        pilha1.adicionar(3);
        pilha1.adicionar(3);
        pilha2.adicionar(1);
        pilha2.adicionar(2);
        pilha2.adicionar(3);
        Guindaste gd = new Guindaste();
        gd.maior(pilha1, pilha2);


    }
}
