public class Pilha {
    Node head;

    public Pilha() {
    }
    
    public void adicionar(int data){
        Node newNode = new Node(data);
        if (head==null) {
            head = newNode;
        }else{
            Node temp = head;
            head = newNode;
            head.next = temp;
        }
    }

    public int somar(){
        int cont=0;
        Node temp = head;
        while (temp!=null) {
            
            cont = cont + temp.data;
            System.out.println(cont+" + "+head.data+" = "+cont);
            temp = temp.next;
            
        }
        return cont;
    }

    public void print(){
        Node temp = head;
        while (temp!=null) {
            
            
            System.out.println(temp.data);
            temp = temp.next;
            
        }
    }
}
