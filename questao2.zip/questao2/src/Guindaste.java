public class Guindaste {
    /*2 - Implemente o algoritmo guindaste_mais_esforcado, que recebe como parâmetros duas pilhas de inteiros representando
        os pesos das cargas movimentadas por cada guindaste. A função deve retornar a pilha do guindaste que realizou o maior esforço total,
        definido como o produto dos pesos movimentados.
        Se ambos os guindastes tiverem o mesmo esforço total, retorne a pilha do segundo guindaste. */
        

    public void maior(Pilha pilha1, Pilha pilha2){
        
        
        if(pilha1.somar() > pilha2.somar()){
            System.out.println("Pilha 1 é maior");
            pilha1.print();
        }else{
            System.out.println("Pilha 2 é maior");
            pilha2.print();
        }
    }
    
}
